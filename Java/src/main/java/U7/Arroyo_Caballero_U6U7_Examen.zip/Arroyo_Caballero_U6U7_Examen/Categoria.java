package U7.Arroyo_Caballero_U6U7_Examen;

public enum Categoria {
    SENIOR,
    JUNIOR,
    VETERANO
}
