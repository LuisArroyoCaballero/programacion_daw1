package U2.T2;
//Ejercicio2-2: Crea un programa que muestre el resto de dividir dos números prefijados.
public class Ejercicio2_2 {
    public static void main (String args[]){
        int primernumero = 60;
        int segundonumero = 10;

        System.out.println(60 % 10);

    }
}
