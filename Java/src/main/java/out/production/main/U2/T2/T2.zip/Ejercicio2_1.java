package U2.T2;
//Ejercicio2-1: Crea un programa en Java que escriba en pantalla el producto de dos números prefijados.
public class Ejercicio2_1 {
    public static void main( String args[] ) {
        System.out.println( 56+24 );

    }

}
