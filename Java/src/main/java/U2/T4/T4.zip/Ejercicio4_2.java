package U2.T4;
//Actividad 4.2 - Necesitamos una aplicación que calcule la media aritmética de dos notas enteras.
// Hay que tener en cuenta que la media puede contener decimales.
public class Ejercicio4_2 {
    public static void main(String arg[]) {
        float nota_1 = 8;
        float nota_2 =9;
        System.out.println((nota_1+nota_2)/2);

    }
}
