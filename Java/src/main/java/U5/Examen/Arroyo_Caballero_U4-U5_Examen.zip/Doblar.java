package U5.Examen;

public interface Doblar {
    public void doblar();
}
