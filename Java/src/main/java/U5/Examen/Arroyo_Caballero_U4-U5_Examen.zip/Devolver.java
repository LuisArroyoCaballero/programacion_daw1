package U5.Examen;

public interface Devolver {
    public void devolver();
}
