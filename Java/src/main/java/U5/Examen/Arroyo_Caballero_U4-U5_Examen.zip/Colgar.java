package U5.Examen;

public interface Colgar {
    public void colgar();
}
