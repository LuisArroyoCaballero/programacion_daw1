package U5.Entregable;

public interface Luchar {
    public void luchar();
}
