package U5.Entregable;

public interface Correr {
    public void correr();
}
