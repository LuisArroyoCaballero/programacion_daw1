package U5.Entregable;

public interface Encestar {
    public void encestar();
}
